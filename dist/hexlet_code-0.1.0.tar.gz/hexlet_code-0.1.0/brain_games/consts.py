AMOUNT_OF_ROUNDS = 3
EVEN_INSTRUCTION = 'Answer "yes" if the number is even, otherwise answer "no".'
CALC_INSTRUCTION = 'What is the result of the expression?'
GCD_INSTRUCTION = "Find the greatest common divisor of given numbers."
PRIME_INSTRUCTION = 'Answer "yes" if given number is prime. ' \
                    'Otherwise answer "no".'
PROGRESSION_INSTRUCTION = "What number is missing in the progression?"
SHORT_PROGR_LENGHT, LONG_PROGR_LENGHT = 5, 10
OPERATORS = ("+", "-", "*")
