MATH_SIGNS = ('+', '-', '*')
