### Hexlet tests and linter status:
[![Actions Status](https://github.com/Maxcosanostra/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Maxcosanostra/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/257c76ddd04f78a6949f/maintainability)](https://codeclimate.com/github/Maxcosanostra/python-project-49/maintainability)

### Brain-even game:
https://asciinema.org/a/uFYpr8OLu9I7RXGJVwauL81K3

### Brain-calc game:
https://asciinema.org/a/YiVSpqBaeC1G5SITnOCeUTsjV

### Brain-gcd game:
https://asciinema.org/a/HQwBo2AxMRgTChXBtpDvIc67Y
